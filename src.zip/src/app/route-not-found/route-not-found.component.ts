import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-not-found',
  templateUrl: './route-not-found.component.html',
  styleUrls: ['./route-not-found.component.scss']
})
export class RouteNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
