import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './core/components/home/home.component';
import { RouteNotFoundComponent } from './route-not-found/route-not-found.component';
import { MlRegistrationComponent } from './core/components/mlregistration/mlregistration.component';
import { LoginComponent } from './core/components/login/login.component';
import { UserlistsComponent } from './core/components/userlists/userlists.component';
import { BloglistsComponent } from './core/components/bloglists/bloglists.component';
import { AddBlogComponent } from './core/components/addblog/addblog.component';
import { ViewcommentsComponent } from './core/components/viewcomments/viewcomments.component';
import { AdminRegistrationComponent } from './core/components/adminregistration/adminregistration.component';

export const routes: Routes = [
  
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'register',
    component: MlRegistrationComponent
  },
  {
    path: 'adminregister',
    component: AdminRegistrationComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'bloglist',
    component: BloglistsComponent
  },
  {
    path: 'addblog',
    component: AddBlogComponent
  },
  {
    path: 'userlist',
    component: UserlistsComponent
  },
  {
    path: 'viewcomments',
    component: ViewcommentsComponent
  },
  {
    path: '',
    component: HomeComponent
  }
];
