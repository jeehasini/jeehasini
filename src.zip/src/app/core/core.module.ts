import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import {MatTabsModule} from '@angular/material/tabs';
import { CalendarHeatmap } from 'angular2-calendar-heatmap';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {ChartsModule} from 'ng2-charts';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { LoginComponent } from './components/login/login.component';
import { MatDialogModule } from '@angular/material/dialog';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatCarouselModule } from '@ngmodule/material-carousel';
import { ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MlRegistrationComponent } from './components/mlregistration/mlregistration.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserlistsComponent } from './components/userlists/userlists.component';
import { BloglistsComponent } from './components/bloglists/bloglists.component';
import { AddBlogComponent } from './components/addblog/addblog.component';
import { ViewcommentsComponent } from './components/viewcomments/viewcomments.component';


@NgModule({
    declarations: [
        HomeComponent,HeaderComponent,FooterComponent, 
        LoginComponent,MlRegistrationComponent,UserlistsComponent,BloglistsComponent,AddBlogComponent,ViewcommentsComponent
    ],
    imports: [
        CommonModule, RouterModule, HttpClientModule, MatTabsModule, FormsModule,BrowserModule, ChartsModule,MatExpansionModule, MatDialogModule, MatFormFieldModule,MatCarouselModule.forRoot(), ScrollingModule, NgbModule,ReactiveFormsModule
    ],
    exports: [HomeComponent, HeaderComponent, FooterComponent],
    entryComponents: [LoginComponent]

})
export class CoreModule { }
