import { Injectable } from '@angular/core';
import { catchError, map } from 'rxjs/operators'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { APP_CONSTANTS } from '../constants';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HttpRequestService {
  public loginInfo: any;
  constructor(private _httpClient: HttpClient, private _router: Router) { }

  private _getHttpHeaders(headerConfig) {

    return new HttpHeaders({
      'Content-Type': headerConfig && headerConfig.contentType ? headerConfig.contentType : 'application/json',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
    }).set('x-eduguy-auth-token', headerConfig && headerConfig.token ? headerConfig.token : '')
  } 

  public request(requestOption): Observable<any> {
    return this._httpClient.request(
      requestOption.method,
      requestOption.url,
      {
        headers: this._getHttpHeaders(requestOption.headerConfig),
        params: requestOption.params,
        body: requestOption.body,
        observe: 'response',
        responseType: requestOption.responseType ? requestOption.responseType : 'json'
      })
      .pipe(
        map(data => this._extractData(data)),
        catchError(data => this._handleError(data))
      );
  }

  private _extractData = (response): any => {
    const data = { data: response.body, status: response.status, headers: response.headers} || {};
    return data;
  }

  private _handleError = (error): Observable<any> => {
    if(error.status === (APP_CONSTANTS.LOGOUT_ERROR_CODES[0] || APP_CONSTANTS.LOGOUT_ERROR_CODES[1])) {
      this._router.navigate(['/login']);
    }
    return throwError(error);

  }

}
