import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { Router, ActivatedRoute, Params} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { LogoutService } from '../../services/logout.service';
import { DeleteService } from '../../services/delete.service';
import { param } from 'jquery';

@Component({
  selector: 'app-deletesection',
  templateUrl: './deletesection.component.html',
  styleUrls: ['./deletesection.component.scss']
})
export class DeletesectionComponent implements OnInit, OnDestroy {

 
  public loggedOut: boolean;
  public studentName: string;
  public studentrole: string;
  public studentId: string;

  public imageBucket = APP_CONSTANTS.IMAGE_BUCKET_PATH;
  submitted = false;
  private _isComponentAlive = true;
  public blogId:any;
  public userId:any;
  public getBlogId:any;
  public getUserId:any;

 constructor( private _router: Router,private route: ActivatedRoute,
    private _tokenService: TokenService,
    private _deleteService:DeleteService,
    private _logoutService: LogoutService) { }

  ngOnInit() { 

   
    this.studentName = localStorage.getItem("student_name"); 
    this.studentrole = localStorage.getItem("student_role");
    this.studentId = localStorage.getItem("student_id");

    const queryString = window.location.search;
    console.log(queryString);

    const urlParams = new URLSearchParams(queryString);

    const getBlogId = urlParams.get('blogId');

    const getUserId = urlParams.get('userId');


    this.blogId = getBlogId;
    this.userId = getUserId;

    if(getBlogId){ 


       this._deleteBlogInfoData(); 

    }


    if(getUserId){ 


       this._deleteUserInfoData(); 

    }
    

    

  }

  public _deleteBlogInfoData() {
    

      this._deleteService.deleteBlogData({
        blogId: this.blogId,
        userId:this.studentId
      })
        .pipe(
          takeWhile(() => this._isComponentAlive)
        )
        .subscribe({ next: this._getStaticDataSuccessHandler, error: this._getStaticDataErrorHandler });
    } 
  
   
  private _getStaticDataSuccessHandler = (data:any) => {
    if (data) {       
       this._router.navigate(['/bloglist'])
       alert("Deleted Successfully");
    }
  }

  private _getStaticDataErrorHandler = () => {
    //error handler
  } 

  public _deleteUserInfoData() {
    
      //alert("hi");
      this._deleteService.deleteUserData({
        userId: this.userId
      })
        .pipe(
          takeWhile(() => this._isComponentAlive)
        )
        .subscribe({ next: this._getStaticUserDataSuccessHandler, error: this._getStaticUserDataErrorHandler });
    } 
  
   
  private _getStaticUserDataSuccessHandler = (data:any) => {
    if (data) {       
       this._router.navigate(['/userlist'])
       alert("Deleted Successfully");
    }
  }

  private _getStaticUserDataErrorHandler = () => {
    //error handler
  } 

  logout(): void {
    localStorage.clear(); 
    this._router.navigate(['/home'])
  }
  
  ngOnDestroy() {
    this._isComponentAlive = false;
  }
}
