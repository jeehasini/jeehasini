import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { LogoutService } from '../../../services/logout.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {  

  constructor(private _router: Router,private _logoutService: LogoutService) { }

  ngOnInit() {}


}
