import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegistrationService } from '../../services/registration.service';
import { param } from 'jquery';


// import custom validator to validate that password and confirm password fields match
import { MustMatch } from './_helpers/must-match.validator';

@Component({
  selector: 'app',
  templateUrl: './mlregistration.component.html',
  styleUrls: ['./mlregistration.component.scss']
})
export class MlRegistrationComponent implements OnInit {

    registerForm: FormGroup;
    submitted = false;
    regemdata:any;
    checkerror:any;
    datanotsaved:any;
    registersuccess:any;

    constructor(private formBuilder: FormBuilder, private _registrationService: RegistrationService, private _router: Router,private route: ActivatedRoute) { }

	 ngOnInit() {
                                 
		this.registerForm = this.formBuilder.group({

		    userName: ['', Validators.required],
		    emailId: ['', [Validators.required, Validators.email]],
		    mobileNo: ['', [Validators.required, Validators.minLength(10)]],
		    password: ['', [Validators.required, Validators.minLength(6)]],
		    confirmPassword: ['', Validators.required],
		    address: ['', Validators.required],
        city: ['', Validators.required],
        roleId:['2']

		}, {
		    validator: MustMatch('password', 'confirmPassword')
		});
 
	}//ngoninit end

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }


    onSubmit() {

        this.submitted = true;

        if (this.registerForm.invalid) { 

           return;

        } else {


           this.saveUserData(this.registerForm.value);         
 
           //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));

        } 
                     
    }

    public saveUserData(data) {

	    console.log('saveUserData ', data)
	    this._registrationService.sendUserInformation(data).subscribe(

        res => { 

          //console.log('GetuserInfo ', res); 

        const getResponsecode =  res.responseCode;

            //console.log(getResponsecode);

            if(getResponsecode == -1 )   {

                 this.checkerror = true;
                 this._router.navigate(['/mlregistration'])

            } else if(getResponsecode == 1 )   {

                 this.registersuccess = true;
                 this._router.navigate(['/login'])

            } else {
                 this.datanotsaved = true;
                 this._router.navigate(['/mlregistration'])
            }
        }
	    );
	    //this._router.navigate(['/login']); 
    
    }

    

    onReset() {
        this.submitted = false;
        this.registerForm.reset();
    }

    backtohome(){

       this._router.navigate(['/home']); 
    }

}
