import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AddBlogService } from '../../services/addblog.service';
import { param } from 'jquery';


@Component({
  selector: 'app-addblog',
  templateUrl: './addblog.component.html',
  styleUrls: ['./addblog.component.scss']
})
export class AddBlogComponent implements OnInit {

    blogForm: FormGroup;
    submitted = false;
    regemdata:any;
    checkerror:any;
    datanotsaved:any;
    registersuccess:any;

    constructor(private formBuilder: FormBuilder, private _addblogService: AddBlogService, private _router: Router,private route: ActivatedRoute) { }

	 ngOnInit() {
                                 
		this.blogForm = this.formBuilder.group({

		    title: ['', Validators.required],
		    description: ['', Validators.required]

		});
 
	 }

    // convenience getter for easy access to form fields
    get f() { return this.blogForm.controls; }


    onSubmit() {

        this.submitted = true;

        if (this.blogForm.invalid) { 

           return;

        } else {


           this.saveBlogData(this.blogForm.value);         
 
           //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.blogForm.value, null, 4));

        } 
                     
    }

    public saveBlogData(data) {

	    console.log('saveBlogData ', data)
	    this._addblogService.saveBlogInformation(data).subscribe(

        res => { 

        const getResponsecode =  res.responseCode;

            console.log(getResponsecode);

            if(getResponsecode == -1 )   {

                 this.checkerror = true;

            } else if(getResponsecode == 1 )   {

                 this.registersuccess = true;

            } else {
                 this.datanotsaved = true;
            }
        }
	    );
	    //this._router.navigate(['/login']); 
    
    }

    

    onReset() {
        this.submitted = false;
        this.blogForm.reset();
    }

    backtohome(){

       this._router.navigate(['/home']); 
    }

}
