import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AddBlogService } from '../../services/addblog.service';
import { param } from 'jquery';


@Component({
  selector: 'app-addblog',
  templateUrl: './addblog.component.html',
  styleUrls: ['./addblog.component.scss']
})
export class AddBlogComponent implements OnInit {

    blogForm: FormGroup;
    submitted = false;
    regemdata:any;
    checkerror:any;
    datanotsaved:any;
    registersuccess:any;
    public studentName: string;
    public studentrole: string;
    public studentId: string;

    constructor(private formBuilder: FormBuilder, private _addblogService: AddBlogService, private _router: Router,private route: ActivatedRoute) { }

	 ngOnInit() {

    this.studentName = localStorage.getItem("student_name"); 
    this.studentrole = localStorage.getItem("student_role");
    this.studentId = localStorage.getItem("student_id");
                                 
		this.blogForm = this.formBuilder.group({

		    title: ['', Validators.required],
		    description: ['', Validators.required],
        MediaType:['1'],
        MediaFileId:['33'],
        IsVisible:['true'],
        UserId:this.studentId 

		});
 
	 }

    // convenience getter for easy access to form fields
    get f() { return this.blogForm.controls; }


    onSubmit() {

        this.submitted = true;

        if (this.blogForm.invalid) { 

           return;

        } else {


           this.saveBlogData(this.blogForm.value);         
 
           //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.blogForm.value, null, 4));

        } 
                     
    }

    public saveBlogData(data) {

	    console.log('saveBlogData ', data)
	    this._addblogService.saveBlogInformation(data).subscribe(

        res => { 

        const getResponsecode =  res.responseCode;

            console.log("getdata",getResponsecode);

            if(getResponsecode == -1 )   {

                 this.checkerror = true;
                 this._router.navigate(['/addblog'])

            } else if(getResponsecode == 1 )   {

                 this.registersuccess = true;
                 this._router.navigate(['/bloglist'])

            } else {
                 this.datanotsaved = true;
                 this._router.navigate(['/addblog'])
            }
        }
	    );
    
    }

    

    onReset() {
        this.submitted = false;
        this.blogForm.reset();
    }

    logout(): void {
    localStorage.clear(); 
    this._router.navigate(['/home'])
  }

    backtoblog(){

       this._router.navigate(['/bloglist']); 
    }

}
