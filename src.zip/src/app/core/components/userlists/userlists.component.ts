import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { LogoutService } from '../../services/logout.service';
import { MyUserDataService } from '../../services/user.service';
import { param } from 'jquery';

@Component({
  selector: 'app-userlists',
  templateUrl: './userlists.component.html',
  styleUrls: ['./userlists.component.scss']
})
export class UserlistsComponent implements OnInit, OnDestroy {

 
  public tokenReceived: boolean;
  public loggedOut: boolean;
  public studentName: string;
  public studentrole: string;

  public imageBucket = APP_CONSTANTS.IMAGE_BUCKET_PATH;
  submitted = false;
  private _isComponentAlive = true;
  public Userdata: any;


 constructor( private _router: Router,private route: ActivatedRoute,
    private _tokenService: TokenService,
    private _userService:MyUserDataService,
    private _logoutService: LogoutService) { }

  ngOnInit() { 

    this._getUserInfoData(); 
    this.studentName = localStorage.getItem("student_name"); 
    this.studentrole = localStorage.getItem("student_role");
      

  }

  
   private _getUserInfoData() {

    this._userService.getMyUserData()
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getMyUserStaticDataSuccessHandler, error: this._getMyUserStaticDataErrorHandler });

  }

  private _getMyUserStaticDataSuccessHandler = (data:any) => {
    if (data) {
      this.Userdata = data;
      console.log("hello",this.Userdata);
    }
  }

  private _getMyUserStaticDataErrorHandler = () => {
    //error handler
  } 

  logout(): void {
    localStorage.clear(); 
    this._router.navigate(['/home'])
  }
  
  ngOnDestroy() {
    this._isComponentAlive = false;
  }
}
