import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private httpClient: HttpClient,private _httpReqService: HttpRequestService) { }

  public getMyBlogData() {

    //console.log("blogchec");
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.LIST_ALL_BLOGS
    }).pipe(
        map(response => this._extractResponse(response))
    );


  }
  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data.blogList;
    } else {
      return false;
    }
  }  
}
