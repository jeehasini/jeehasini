import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor( private httpClient: HttpClient, private _httpReqService: HttpRequestService) { }

  public sendUserInformation(requestBody: { userName, emailId, password, roleId, mobileNo, address,city }): Observable<any> {
    return this.httpClient.post<any>(environment.SERVICE_APIS.POST_USERDATA, requestBody);
  }

  private _extractResponse = (response: { data: any, statusCode: number,err }) => {
    //console.log("extract response");
    console.log('chk res ',response);
    if (response.statusCode === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return;
    } else if (response.data.statusCode === APP_CONSTANTS.FAILURE_RESPONSE_CODES) {
      return response.data.err;
    } else {
      return false;
    }
  }   
  
}
