import { Injectable } from '@angular/core';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { HttpRequestService } from '../http-request.service';
import { map } from 'rxjs/operators';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

   constructor(private _httpReqService: HttpRequestService, private _router: Router) {

    }


  public getCommentData(requestBody: { blogId}) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.GET_COMMENTS,
      body: requestBody
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data.commentList;
    } else {
      return false;
    }
  } 

  
}
