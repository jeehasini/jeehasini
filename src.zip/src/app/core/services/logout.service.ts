import { Injectable } from '@angular/core';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LogoutService {

  constructor(private _httpReqService: HttpRequestService) { }

  attemptLogout(requestBody: {email}, token){

    //localStorage.clear(); 
    localStorage.removeItem("cartamount"); 
    localStorage.removeItem("getopinion"); 
    localStorage.removeItem("lookingfor"); 
    localStorage.removeItem("s.age"); 
    localStorage.removeItem("s.email"); 
    localStorage.removeItem("s.gender");
    localStorage.removeItem("s.name");
    localStorage.removeItem("s.phone_number");
    localStorage.removeItem("s.stateName");
    localStorage.removeItem("s.uniqueid");
    localStorage.removeItem("student_email");
    localStorage.removeItem("student_id");
    localStorage.removeItem("student_name");
    localStorage.removeItem("token"); 
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.ATTEMPT_LOGOUT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }
}
