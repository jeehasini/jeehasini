import { Injectable } from '@angular/core';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MyUserDataService {

  constructor(private _httpReqService: HttpRequestService,private _router: Router) { }

  public getMyUserData() {

    //console.log("blogchec");
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.LIST_ALL_USERS
    }).pipe(
        map(response => this._extractResponse(response))
    );


  }

   private _extractResponse = (response: { data: any, status: number }) => {

    //console.log(response.data.responseCode); 
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data.userList;
    } else {
      return false;
    }
   }  

}


