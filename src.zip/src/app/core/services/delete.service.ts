import { Injectable } from '@angular/core';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { HttpRequestService } from '../http-request.service';
import { map } from 'rxjs/operators';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DeleteService {

   constructor(private _httpReqService: HttpRequestService, private _router: Router) {

    }


  public deleteBlogData(requestBody: { blogId,userId}) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.REMOVE_BLOG,
      body: requestBody
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  public deleteUserData(requestBody: { userId}) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.REMOVE_USER,
      body: requestBody
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  private _extractResponse = (response: { data: any, status: number }) => {

    console.log(response);
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } else {
      return false;
    }
  } 

  
}
