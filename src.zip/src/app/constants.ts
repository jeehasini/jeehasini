export const APP_CONSTANTS = {
    
    
    // PROD SERVER
    URI: 'http://103.235.106.109/plesk-site-preview/capstones.com/api/',

    IMAGE_BUCKET_PATH: 'http://103.235.106.109/plesk-site-preview/capstones.com/',
    
    API_METHODS: {
        'GET': 'GET',
        'POST': 'POST',
        'PUT': 'PUT',
        'DELETE': 'DELETE'
    },
    SUCCESS_RESPONSE_CODES: 200,
    FAILURE_RESPONSE_CODES: 400,
    LOGOUT_ERROR_CODES: [401, 402],
    ERROR_RESPONSE_CODES: [404, 500, 400]
}


