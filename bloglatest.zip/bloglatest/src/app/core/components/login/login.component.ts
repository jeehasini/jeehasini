import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeWhile } from 'rxjs/operators';
import { MatDialogRef } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

	  private _isComponentAlive = true;
	  public loginInfo: any;
	  public cancelclicked:any;
	  public _token: any;
	  public noUser: boolean;
	  public loginFailed: boolean;
	  errorMsgToUI: any;
	  reDirectUrl: any;
	  public student_id: any;
	  public student_name: any;
	  public email: any;
	  public emailId:any;
	  public token: any;
	  public studentName: string;
	  public studentEmail: string;
	  public tokenReceived: boolean;
	  public loggedOut: boolean;
	  public tokenVal: string;



	constructor(private _router: Router, private _tokenService: TokenService) {

	  }

	  public userDetail = {
	    emailId: '',
	    password: ''
	  }

	  ngOnInit() {}

	public sendLogin() {
    
	    this.noUser = false;
	    this.loginFailed = false;
	    this._tokenService.postLoginInfo({
	      emailId: this.userDetail.emailId,
	      password: this.userDetail.password //to add country code in url
	    })
	      .pipe(
	        takeWhile(() => this._isComponentAlive)
	      )
	      .subscribe({ next: this._attemptLoginSuccessHandler, error: this._attemptLoginErrorHandler });
    }


    private _attemptLoginSuccessHandler = (response) => {

    if (response) {

       const getResponsecode =  response.data.responseCode;

       if(getResponsecode == 0 )   {

           localStorage.setItem("student_id", "");
	       localStorage.setItem("student_name","");
	       this.loginFailed=true;
	       this._router.navigate(['/login'])

       } else {


           this.loginInfo = response.data.userDetails; 

           console.log("hoooo",response.data.userDetails);

		      const receivedStudentInfo = {
		        student_id: this.loginInfo.userId,
		        student_name: this.loginInfo.userName,
		        student_email: this.loginInfo.emailId
		      } 

		   localStorage.setItem("student_id", this.loginInfo.student_id);
	       localStorage.setItem("student_name",this.loginInfo.userName);
	       localStorage.setItem("student_role",this.loginInfo.roleId);

	       this._router.navigate(['/home'])  

       }     
      
      
    } // End of If response

  }  // End of attemptLoginSuccessHandler

  private _attemptLoginErrorHandler = (error) => {
    this.errorMsgToUI = error.error.err;
    this.reDirectUrl = error.error.redirectURL;
    if (error.error.err === 'Please Register') {
      this.noUser = true;
    }
    else {
      this.loginFailed=true;
      this._router.navigate(['/login']); //to add country code in url
    }
  }

  onNoClick(): void {
    this.cancelclicked=true;
    this._router.navigate(['/home'])
  }

  ngOnDestroy() {
    this._isComponentAlive = false;
  }
          
}
