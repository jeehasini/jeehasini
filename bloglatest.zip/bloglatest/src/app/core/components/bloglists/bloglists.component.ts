import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { LogoutService } from '../../services/logout.service';
import { HomeService } from '../../services/home.service';
import { param } from 'jquery';

@Component({
  selector: 'app-bloglists',
  templateUrl: './bloglists.component.html',
  styleUrls: ['./bloglists.component.scss']
})
export class BloglistsComponent implements OnInit, OnDestroy {

 
  public tokenReceived: boolean;
  public loggedOut: boolean;
  public studentName: string;
  public studentrole: string;

  public imageBucket = APP_CONSTANTS.IMAGE_BUCKET_PATH;
  submitted = false;
  private _isComponentAlive = true;
  public Blogdata: any;


 constructor( private _router: Router,private route: ActivatedRoute,
    private _tokenService: TokenService,
    private _homeService:HomeService,
    private _logoutService: LogoutService) { }

  ngOnInit() { 

    this._getBlogInfoData();  
    this.studentName = localStorage.getItem("student_name"); 
    this.studentrole = localStorage.getItem("student_role");
      

  }

  
  private _getBlogInfoData() {

    this._homeService.getMyBlogData()
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getMyBlogStaticDataSuccessHandler, error: this._getMyBlogStaticDataErrorHandler });

  }

  private _getMyBlogStaticDataSuccessHandler = (data:any) => {
    if (data) {
      this.Blogdata = data;
      console.log("hello",this.Blogdata);
    }
  }

  private _getMyBlogStaticDataErrorHandler = () => {
    //error handler
  } 

  logout(): void {
    localStorage.clear(); 
    this._router.navigate(['/home'])
  }
  
  ngOnDestroy() {
    this._isComponentAlive = false;
  }
}
