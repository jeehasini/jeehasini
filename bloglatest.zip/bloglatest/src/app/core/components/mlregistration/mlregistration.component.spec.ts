import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MlRegistrationComponent } from './mlregistration.component';

describe('MlRegistrationComponent', () => {
  let component: MlRegistrationComponent;
  let fixture: ComponentFixture<MlRegistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MlRegistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MlRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
