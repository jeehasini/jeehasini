import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { Router, ActivatedRoute, Params} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { LogoutService } from '../../services/logout.service';
import { CommentService } from '../../services/comment.service';
import { param } from 'jquery';

@Component({
  selector: 'app-viewcomments',
  templateUrl: './viewcomments.component.html',
  styleUrls: ['./viewcomments.component.scss']
})
export class ViewcommentsComponent implements OnInit, OnDestroy {

 
  public tokenReceived: boolean;
  public loggedOut: boolean;
  public studentName: string;
  public studentrole: string;

  public imageBucket = APP_CONSTANTS.IMAGE_BUCKET_PATH;
  submitted = false;
  private _isComponentAlive = true;
  public Commentsdata: any;
  public blogId:any;
  public getBlogId:any;

 constructor( private _router: Router,private route: ActivatedRoute,
    private _tokenService: TokenService,
    private _commentService:CommentService,
    private _logoutService: LogoutService) { }

  ngOnInit() { 

   
    this.studentName = localStorage.getItem("student_name"); 
    this.studentrole = localStorage.getItem("student_role");

    const queryString = window.location.search;
    //console.log(queryString);

    const urlParams = new URLSearchParams(queryString);

    const getBlogId = urlParams.get('blogId')

    this.blogId = getBlogId;

    this._getBlogInfoData(); 

  }

  public _getBlogInfoData() {
    

      this._commentService.getCommentData({
        blogId: this.blogId
      })
        .pipe(
          takeWhile(() => this._isComponentAlive)
        )
        .subscribe({ next: this._getMyBlogStaticDataSuccessHandler, error: this._getMyBlogStaticDataErrorHandler });
    } 
  
   
  private _getMyBlogStaticDataSuccessHandler = (data:any) => {
    if (data) {
      this.Commentsdata = data;
      console.log("hello",this.Commentsdata);
    }
  }

  private _getMyBlogStaticDataErrorHandler = () => {
    //error handler
  } 

  logout(): void {
    localStorage.clear(); 
    this._router.navigate(['/home'])
  }
  
  ngOnDestroy() {
    this._isComponentAlive = false;
  }
}
