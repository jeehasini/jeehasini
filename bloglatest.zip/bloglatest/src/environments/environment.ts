// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { APP_CONSTANTS } from 'src/app/constants';

export const environment = {
  production: false,
  SERVICE_APIS: {

    ATTEMPT_LOGIN: APP_CONSTANTS.URI + 'blog/login',
    POST_USERDATA: APP_CONSTANTS.URI + 'user/createuser',
    LIST_ALL_BLOGS: APP_CONSTANTS.URI + 'blog/getAllBlog',
    LIST_ALL_USERS: APP_CONSTANTS.URI + 'blog/getAllUsers',
    POST_BLOGDATA: APP_CONSTANTS.URI + 'blog/saveBlog',
    GET_COMMENTS: APP_CONSTANTS.URI + 'blog/getAllComments',

    ATTEMPT_PAID_REGISTRATION: APP_CONSTANTS.URI + '/api/v1/registration',
    ATTEMPT_LOGOUT: APP_CONSTANTS.URI + '/api/v1/logout',    
    GET_DASHBOARD_DATA: APP_CONSTANTS.URI + '/api/v1/student/dashboard/home',
    
    POST_SENDSMS: APP_CONSTANTS.URI + '/api/v1/sendSMS/response',
    POST_VALIDATEEMAIL : APP_CONSTANTS.URI + '/api/v1/checkUserData/validateEmail',
    EXISTS_EMAIL : APP_CONSTANTS.URI + '/api/v1/checkUserData/existsEmail',
    POST_VALIDATEPHONE : APP_CONSTANTS.URI + '/api/v1/checkUserData/validatePhoneNo',
    POST_FORGETEMAIL : APP_CONSTANTS.URI + '/api/v1/checkUserData/sendforgetEmail',
  
    

  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
